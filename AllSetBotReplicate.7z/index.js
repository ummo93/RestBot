require('babel-register');
require('babel-polyfill');
require('./server');
console.log("ES6 init");

